local jailCoords = vector4(-2006.8740, 3183.4316, 32.8103, 150.1299)
local releaseCoords = vector4(-2247.1018, 3246.3225, 32.8102, 240.8955)
local jailRadius = 25.0

local jailActive = false
local jailTime = 0
local jailReason = ""
local timer = 0

function DrawJailUI(timeLeft, reason)
    local minutes = math.floor(timeLeft / 60)
    local seconds = timeLeft % 60
    local text = ("?? Im Gef�ngnis | Grund: %s | Zeit: %02d:%02d verbleibend"):format(reason, minutes, seconds)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextScale(0.5, 0.5)
    SetTextColour(255, 255, 255, 255)
    SetTextDropshadow(2, 2, 2, 2, 255)
    SetTextEdge(2, 0, 0, 0, 150)
    SetTextCentre(1)
    BeginTextCommandDisplayText("STRING")
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(0.5, 0.03)
    -- Stylish background bar
    DrawRect(0.5, 0.045, 0.6, 0.045, 10, 10, 10, 180)
end

local function TeleportToJail()
    SetEntityCoords(PlayerPedId(), jailCoords.x, jailCoords.y, jailCoords.z, false, false, false, true)
    SetEntityHeading(PlayerPedId(), jailCoords.w)
end

local function TeleportToRelease()
    SetEntityCoords(PlayerPedId(), releaseCoords.x, releaseCoords.y, releaseCoords.z, false, false, false, true)
    SetEntityHeading(PlayerPedId(), releaseCoords.w)
end

RegisterNetEvent("jail:start")
AddEventHandler("jail:start", function(seconds, reason)
    jailActive = true
    jailTime = seconds
    jailReason = reason
    timer = seconds
    Citizen.CreateThread(function()
        TeleportToJail()
        while jailActive and timer > 0 do
            Citizen.Wait(1000)
            timer = timer - 1
            -- Re-Teleport wenn Spieler zu weit weg
            local dist = #(GetEntityCoords(PlayerPedId()) - vector3(jailCoords.x, jailCoords.y, jailCoords.z))
            if dist > jailRadius then
                TeleportToJail()
            end
        end
        if jailActive then -- Falls nicht durch forceRelease beendet
            jailActive = false
            TeleportToRelease()
            TriggerServerEvent('jail:release')
            jailReason = ""
        end
    end)
end)

RegisterNetEvent("jail:forceRelease")
AddEventHandler("jail:forceRelease", function()
    jailActive = false
    timer = 0
    TeleportToRelease()
    TriggerServerEvent('jail:release')
    jailReason = ""
end)

-- UI Draw Loop
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if jailActive and timer > 0 then
            DrawJailUI(timer, jailReason)
            DisableControlAction(0, 75, true) -- Disable exit vehicle
            DisableControlAction(0, 23, true) -- Disable exit vehicle
        end
    end
end)

-- Bei Respawn/Tod wieder ins Jail
AddEventHandler('playerSpawned', function()
    Citizen.Wait(500)
    if jailActive and timer > 0 then
        TeleportToJail()
    else
        TriggerServerEvent("jail:check")
    end
end)

-- Anti-Exploit (Falls Jail-Status beim Joinen vergessen wurde)
AddEventHandler('onClientMapStart', function()
    TriggerServerEvent("jail:check")
end)