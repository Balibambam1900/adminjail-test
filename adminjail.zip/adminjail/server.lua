local admins = {
    -- Trage hier deine Admin-Steam-IDs ein (ohne "steam:" davor)
    ["11000016e425dd1"] = true, -- Beispiel: steam:11000010abcdef12
}

local jailedPlayers = {}

RegisterCommand("jail", function(source, args, rawCommand)
    local adminSteam = GetPlayerIdentifierByType(source, "steam")
    if not adminSteam or not admins[adminSteam:gsub("steam:", "")] then
        TriggerClientEvent('chat:addMessage', source, { args = {"Jail", "Du bist kein Admin!"}})
        return
    end

    local targetId = tonumber(args[1])
    local jailTime = tonumber(args[2])
    local reason = table.concat(args, " ", 3)

    if not targetId or not jailTime or jailTime < 1 or not reason or reason == "" then
        TriggerClientEvent('chat:addMessage', source, { args = {"Jail", "Syntax: /jail [ID] [Minuten] [Grund]"}})
        return
    end

    if GetPlayerName(targetId) == nil then
        TriggerClientEvent('chat:addMessage', source, { args = {"Jail", "Spieler nicht gefunden!"}})
        return
    end

    jailedPlayers[targetId] = {
        time = jailTime * 60,
        reason = reason
    }

    TriggerClientEvent('jail:start', targetId, jailTime * 60, reason)
    TriggerClientEvent('chat:addMessage', source, { args = {"Jail", "Spieler wurde eingesperrt!"}})
end)

RegisterCommand("unjail", function(source, args, rawCommand)
    local adminSteam = GetPlayerIdentifierByType(source, "steam")
    if not adminSteam or not admins[adminSteam:gsub("steam:", "")] then
        TriggerClientEvent('chat:addMessage', source, { args = {"Jail", "Du bist kein Admin!"}})
        return
    end

    local targetId = tonumber(args[1])
    if not targetId or GetPlayerName(targetId) == nil then
        TriggerClientEvent('chat:addMessage', source, { args = {"Jail", "Syntax: /unjail [ID]"}})
        return
    end

    if jailedPlayers[targetId] then
        jailedPlayers[targetId] = nil
        TriggerClientEvent('jail:forceRelease', targetId)
        TriggerClientEvent('chat:addMessage', source, { args = {"Jail", "Spieler wurde entlassen!"}})
    else
        TriggerClientEvent('chat:addMessage', source, { args = {"Jail", "Spieler ist nicht im Jail!"}})
    end
end)

RegisterServerEvent('jail:release')
AddEventHandler('jail:release', function()
    local src = source
    jailedPlayers[src] = nil
end)

RegisterServerEvent('jail:check')
AddEventHandler('jail:check', function()
    local src = source
    if jailedPlayers[src] then
        TriggerClientEvent('jail:start', src, jailedPlayers[src].time, jailedPlayers[src].reason)
    end
end)

AddEventHandler('playerDropped', function()
    local src = source
    jailedPlayers[src] = nil
end)

function GetPlayerIdentifierByType(source, idtype)
    for i=0,GetNumPlayerIdentifiers(source)-1 do
        local id = GetPlayerIdentifier(source, i)
        if string.find(id, idtype..":") == 1 then
            return id
        end
    end
    return nil
end