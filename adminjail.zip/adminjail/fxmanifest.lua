fx_version 'cerulean'
game 'gta5'

author 'Lord Bali'
description 'Admin Jail Script'
version '1.0.1'

server_script 'server.lua'
client_script 'client.lua'